﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class BaseBattlerClass
    {
        private string battlerName;
        private string battlerPassword;
        private int battlerMaxHP;
        private int battlerCurrentHP;
        private BaseWeapon weapon;

        public string BattlerName
        {
            get { return battlerName; }
            set { battlerName = value; }
        }

        public string BattlerPassword
        {
            get { return battlerPassword; }
            set { battlerPassword = value; }
        }

        public int BattlerMaxHP
        {
            get { return battlerMaxHP; }
            set { battlerMaxHP = value; }
        }

        public int BattlerCurrentHP
        {
            get { return battlerCurrentHP; }
            set { battlerCurrentHP = value; }
        }

        public BaseWeapon Weapon
        {
            get { return weapon; }
            set { weapon = value; }
        }
    }
}
