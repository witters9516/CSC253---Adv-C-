﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using ClassLibrary;

namespace DungeonCrawl
{
    public partial class DungeonCrawlGame : Form
    {
        public DungeonCrawlGame()
        {
            InitializeComponent();
        }

        private void DungeonCrawlGame_Load(object sender, EventArgs e)
        {

        }

        //Map Changing Functions
        private void northButton_Click(object sender, EventArgs e)
        {

        }

        private void southButton_Click(object sender, EventArgs e)
        {

        }

        //Battle Target related functions
        private void attackButton_Click(object sender, EventArgs e)
        {

        }

        private void enemyListBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

    }
}
